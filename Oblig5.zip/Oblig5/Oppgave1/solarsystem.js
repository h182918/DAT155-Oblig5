/**
 * Our solar system. Remember, Separation of Concerns is the most important design pattern!
 */
class SolarSystem {
    constructor(state) {
        this.state = state; // Store the injected state

        // define sun settings
        let sunTextureUrl = 'assets/texture_sun.jpg';
        let radius = 5;
        let widthSegments = 64; // How many segments there are horizontally around the sphere
        let heightSegments = 64; // How many segments there are vertically around the sphere

        // Create the sun
        let sunTex = new THREE.TextureLoader().load(sunTextureUrl); // First we load the texture
        let sunGeometry = new THREE.SphereGeometry(radius, widthSegments, heightSegments); // Create a sphere geometry using the settings above

        // Create our sun's material (shading settings), using the MeshBasicMaterial so the sun is always illuminated.
        // let sunMaterial = SimpleColorMaterial(sunTex); // Create our custom material
        // sunMaterial.uniforms.colorMask.value = new THREE.Color('#aaFF33'); // Change the value of the colorMask uniform
        let sunMaterial = new THREE.MeshBasicMaterial({ map: sunTex }); // set the map option of the settings object to the sun texture we created
        this.sun = new THREE.Mesh(sunGeometry, sunMaterial); // Create the Mesh for the sun, which is the complete sun object that contains the geometry and material, ready for rendering.
        this.state.scene.add(this.sun); // Add the sun to the scene

        // create a point light and set it as a child of the sun (so the sun shines on other objects), use 5 as intensity (play around and see what this does for yourselves)
        this.sunlight = new THREE.PointLight(0xffffff, 3);
        this.sun.add(this.sunlight); // Add the sunlight as a child of the sun

        // Create an orbit node for the earth around the sun (Same concept as the WebGLScenegraph)
        this.earthOrbitAroundSun = new THREE.Object3D(); // Since an orbit has no visible geometry, we create an Object3D for this.
        this.sun.add(this.earthOrbitAroundSun); // Add as a child of the sun, so the orbit will be around the center of the sun.

        // after the sun has been added, we need to add the earth to it's orbit

        radius = 2.5; // change to very unrealistic, but at least smaller, radius
        let earthTextureUrl = 'assets/texture_earth.jpg'; // declare the texture url

        // Create and add earth, same procedure as before
        let earthTex = new THREE.TextureLoader().load(earthTextureUrl);
        let earthGeometry = new THREE.SphereGeometry(radius, widthSegments, heightSegments);

        // Create our sun's material, using the MeshPhongMaterial (Phong shading) so it receives light from light-emitting objects in the scene.
        let earthMaterial = new THREE.MeshPhongMaterial({ map: earthTex, shininess: 1.0 }); // set the map option of the settings object to the earth texture, and set the shininess of the lightmodel to 1.0 (very low)
        this.earth = new THREE.Mesh(earthGeometry, earthMaterial);

        this.earth.position.x = 15; // Translate earth out from the sun
        this.earthOrbitAroundSun.add(this.earth); // Add the earth to the earthOrbitAroundSun, so we can control the orbit independently of the sun's spin.


        //Create an orbit node for the moon around the Earh
        this.moonOrbitAroundEarth = new THREE.Object3D();
        this.earth.add(this.moonOrbitAroundEarth);

        radius= 1.5;
        let moonTextureUrl = 'assets/texture_moon.jpg';

        let moonTex = new THREE.TextureLoader().load(moonTextureUrl);
        let moonGeometry = new THREE.SphereGeometry(radius, widthSegments, heightSegments);

        let moonMaterial =   new THREE.MeshPhongMaterial({map: moonTex, shininess: 1.0});
        this.moon =  new THREE.Mesh(moonGeometry, moonMaterial);

        this.moon.position.x = 5;
        this.moonOrbitAroundEarth.add(this.moon);


        //Create an orbit node for venus around the sun.
        this.venusOrbitArondSun = new THREE.Object3D();
        this.sun.add(this.venusOrbitArondSun);

        radius = 1.5;
        let venusTextureUrl = 'assets/texture_venus.jpg';

        let venusTex = new THREE.TextureLoader().load(venusTextureUrl);
        let venusGeometry = new THREE.SphereGeometry(radius, widthSegments, heightSegments);

        let venusMaterial =   new THREE.MeshPhongMaterial({map: venusTex, shininess: 1.0});
        this.venus =  new THREE.Mesh(venusGeometry, venusMaterial);

        this.venus.position.x = 10;
        this.venusOrbitArondSun.add(this.venus);

        // Create a soft atmospheric white light so that we can just barely see the dark side of the earth.
        // Ambient light has no direction, and is applied to all objects in the scene.
        let amb = new THREE.AmbientLight(0xffffff, 0.05);
        this.state.scene.add(amb); // Add the light to the scene.

        this.state.animate_objects.push(this); // Add this object to the state's animate_objects array, so the animate function is called each render pass
    }

    // Lets do all the updating of our objects in this method, so we can just call this from the render method in app.js!
    animate() {
        this.rotateObject(this.sun, [0.0, 0.005, 0.0]); // Spin the sun gently around its own axis
        this.rotateObject(this.earthOrbitAroundSun, [0.0, 0.01, 0.0]); // rotate the earth orbit, thereby rotating the earth which is its child, in orbit around the sun
        this.rotateObject(this.earth, [0.0, 0.02, 0.0]); // Spin the earth around its own axis
        this.rotateObject(this.moon, [0.0, 0.03, 0.0]);
        this.rotateObject(this.moonOrbitAroundEarth,[0.0, 0.03, 0.0]);
        this.rotateObject(this.venus, [0.0, 0.02, 0.0]);
        this.rotateObject(this.venusOrbitArondSun,[0.0, 0.03, 0.0]);
    }

    // Helper function
    rotateObject(object, rotation) {
        object.rotation.x += rotation[0];
        object.rotation.y += rotation[1];
        object.rotation.z += rotation[2];
    }
}
