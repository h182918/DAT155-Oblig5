
export default class CollisionObject {

    constructor(mesh, isDynamic = false) {

        this.mesh = mesh;

        this._onIntersect = null;

        this._destroy = false;

        this.dynamic = isDynamic;

    }

    setOnIntersectListener(listener) {
        this._onIntersect = listener.bind(this);
    }

    destroy() {
        this._destroy = true;
    }

 }